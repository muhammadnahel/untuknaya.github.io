CARA PAKAI
1. Buka index.html (double-click) atau upload folder ini ke hosting (Netlify/GitHub Pages/Vercel).
2. Edit config.js: nama, foto (src: "foto1.jpg"), isi surat, playlist, dan musik (musicUrl: "lagu.mp3").
   Taruh file foto/lagu di folder yang sama dengan index.html.
3. Musik bawaan = chiptune 8-bit yang dibuat lewat kode (WebAudio), mulai saat tombol "Let's Go!" ditekan.
File: index.html (struktur) | style.css (tampilan & efek) | app.js (logika, musik, confetti) | config.js (isi)
